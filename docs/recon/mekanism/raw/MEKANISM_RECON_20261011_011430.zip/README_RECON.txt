﻿YAN MEKANISM RECON v1
=====================

RUN
---
2026-10-11T01:15:45.1725835+03:00

INSTANCE
--------
C:\Users\yan\AppData\Roaming\ElyPrismLauncher\instances\1.21.1

CORE JAR
--------
C:\Users\yan\AppData\Roaming\ElyPrismLauncher\instances\1.21.1\minecraft\mods\Mekanism-1.21.1-10.7.19.85.jar

SHA256
------
004DBC9F3106F4D192AEAA1EE1190DD16EC9CA8059ED3D093B80034F4C574F43

RELATED JARS
------------
mekanism_extras-1.21.1-1.4.1.jar
Mekanism-1.21.1-10.7.19.85.jar
MekanismAdditions-1.21.1-10.7.19.85.jar
MekanismGenerators-1.21.1-10.7.19.85.jar
MekanismTools-1.21.1-10.7.19.85.jar

COUNTS
------
Outer classes: 2026
Target javap classes: 120
Semantic hits: 4519

WHAT THIS RECON CAPTURES
------------------------
1. Exact installed Mekanism JAR identity.
2. Full JAR entry list.
3. Mod descriptor / manifest when present.
4. Mekanism data/recipe resource paths.
5. All outer class names.
6. Scored classes likely related to:
   - logistical transporters
   - inventory insertion/extraction
   - side configuration
   - auto eject
   - factories
   - recipes
   - energy
   - slots
   - capabilities
   - sorter / filters
7. Bytecode signatures and instructions via javap.
8. A semantic-hit index for the main mechanics.

WHY JAVAP FIRST
---------------
This pass requires no internet and no external decompiler.
It gives us the exact classes/methods from YOUR installed version.

After this ZIP is inspected, the next pass can decompile only the
important classes instead of dumping the entire mod blindly.

NEXT
----
Upload the generated MEKANISM_RECON_*.zip back into ChatGPT.
