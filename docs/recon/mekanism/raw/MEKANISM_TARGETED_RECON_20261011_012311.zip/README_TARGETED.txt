﻿YAN MEKANISM TARGETED RECON v2
==============================

Exact JAR:
C:\Users\yan\AppData\Roaming\ElyPrismLauncher\instances\1.21.1\minecraft\mods\Mekanism-1.21.1-10.7.19.85.jar

SHA256:
004DBC9F3106F4D192AEAA1EE1190DD16EC9CA8059ED3D093B80034F4C574F43

Classes requested:
37

Classes successful:
37

Classes failed:
0

WHY THIS PASS EXISTS
--------------------
Recon v1 identified the important architecture, but it intentionally
missed several low-scoring classes that contain the exact constants and
contracts we now need.

This targeted pass captures:
- transporter tier speed / pull amount
- connection mode semantics
- path and round-robin machinery
- logistical sorter timing and modes
- machine side configuration
- auto-eject mechanics
- energized smelter base process time
- energy container behavior
- factory tier/process counts
- config classes for machine usage/storage

NEXT
----
Upload the generated MEKANISM_TARGETED_RECON_*.zip.
After that we can freeze Mekanism Oracle v1 and start the real
MekanismTechnologyAdapter instead of doing another broad scan.
